local speedShow = false


local open = false
Citizen.CreateThread(function()
    while true do
        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        
        if vehicle ~= 0 then 
            local speed = GetEntitySpeed(vehicle) * 3.6 

            if not open then
                open = true
            end
            SendNUIMessage({
                type = 'speedVar',
                payload = open,
                carSpeed = math.floor(speed),
            })

            DrawTextOnScreen(0.35, 0.25, "Speed: " .. tostring(math.floor(speed)) .. " km/h")
        else
            if open then
                open = false
                SendNUIMessage({
                    type = 'speedVar',
                    payload = open,
                })
            end

            print('Oyuncu araç içinde değil')
        end

        Citizen.Wait(1) 
    end
end)

function DrawTextOnScreen(x, y, text)
    SetTextFont(0)
    SetTextProportional(1)
    SetTextScale(0.5, 0.5)
    SetTextColour(255, 255, 255, 255)
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x, y)
end


RegisterCommand('spawn', function(source, args, raw)
    local model = args[1]
    local playerCoords = GetEntityCoords(PlayerPedId())
    local playerHeading = GetEntityHeading(PlayerPedId())
    if model ~= nil then 
        local modelHash = GetHashKey(model)
        RequestModel(modelHash) 
        local isLoaded = HasModelLoaded(modelHash)
        while isLoaded == false do 
            Citizen.Wait(100)
        end
        local vehicle = CreateVehicle(modelHash, playerCoords.x, playerCoords.y, playerCoords.z, playerHeading, true, false)
        SetPedIntoVehicle(PlayerPedId(), vehicle, -1)
    end



end)

RegisterCommand('dv', function(source, args, raw)
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    if vehicle ~= 0 then
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteVehicle(vehicle)
    end
end)


