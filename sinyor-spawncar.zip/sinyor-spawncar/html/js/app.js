const app = Vue.createApp({
    data() {
        return {
            carHud: false,
            carSpeed: 0,
        }
    },

    methods: {
        handleMessage(event) {
            let data = event.data;
            if (data.type === "speedVar") {
                this.carHud = data.payload;
                this.carSpeed = data.carSpeed || 0; 
            }
        },
    },
    mounted() {
        window.addEventListener('message', this.handleMessage);
        document.addEventListener('keydown', this.handleKeydown);
        document.addEventListener('click', this.handleButtonClick);
    },
    beforeUnmount() {
        window.removeEventListener('message', this.handleMessage);
        document.removeEventListener('keydown', this.handleKeydown);
        document.removeEventListener('click', this.handleButtonClick);
    }
});

app.mount('#app');